<?php



	$mysql_server_name='localhost'; //Mysql数据库服务器
	
	$mysql_username='ser9257516814'; //Mysql数据库用户名
	
	$mysql_password='5wmoGA'; //Mysql数据库密码
	
	$mysql_database='ser9257516814'; //Mysql数据库名
?>