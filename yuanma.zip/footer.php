<?php
//版本V1.0

//http://www.xmpan.com

//http://www.xmpan.com
?>

<!-- 底部引入页面 -->
					</div> <!-- container -->

                </div> <!-- content -->

                <!-- 页脚 -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                版权所有 © <?php echo $result['footer'];?>
                                <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? "https://" : "http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1269074974'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1269074974%26online%3D2' type='text/javascript'%3E%3C/script%3E"));</script>
                            </div>
                          
                            <div class="col-md-6">
                                <div class="text-md-right footer-links d-none d-sm-block">
									友情链接:<?php echo $result['yqlj'];?>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- 页脚 -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
       <script src="./assets/javascript/app.min.js"></script>
    </body>
</html>