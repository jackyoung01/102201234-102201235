<link rel="stylesheet" href="https://getbootstrap.com/assets/css/docs.min.css" />
<link href="../plug/time-selection/assets/theme/css/base.css" rel="stylesheet">
<link href="../plug/time-selection/css/highlight.min.css" rel="stylesheet">
<link href="../plug/time-selection/assets/theme/css/tempusdominus-bootstrap-4.css" rel="stylesheet">
<script src="../plug/time-selection/js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script type="text/javascript" src="../plug/time-selection/js/popper.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../plug/time-selection/js/moment-with-locales.min.js"></script>
<script type="text/javascript" src="../plug/time-selection/js/moment-timezone-with-data-2012-2022.min.js"></script>
<script src="../plug/time-selection/assets/theme/js/base.js"></script>
<script src="../plug/time-selection/js/highlight.min.js"></script>
<script src="../plug/time-selection/assets/theme/js/tempusdominus-bootstrap-4.js"></script>