<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "ca54c0943acc7a43406daf18970fdf98");
define("PRIVATE_KEY", "576dc185cd9fd7dc55d668538154e9de");



 ?>