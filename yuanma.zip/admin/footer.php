<?php

//http://www.xmpan.com

//http://www.xmpan.com
?>
<!-- 底部引入页面 -->
<?php include '../jb.php';?>
					</div> <!-- container -->

                </div> <!-- content -->

                <!-- 页脚 -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                版权所有 © <?php echo $result['footer'];?>
                            </div>
                          
                            <div class="col-md-6">
                                <div class="text-md-right footer-links d-none d-sm-block">
									友情链接:<?php echo $result['yqlj'];?>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- 页脚 -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- App js -->
        <script src="../assets/javascript/app.min.js"></script>
    </body>
</html>